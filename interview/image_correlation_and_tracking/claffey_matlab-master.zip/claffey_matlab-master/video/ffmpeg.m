function [cmd] = ffmpeg(mov)

    error('use ffmpeg_build');
           
end
           

