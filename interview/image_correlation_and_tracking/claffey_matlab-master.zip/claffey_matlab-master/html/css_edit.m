function css_edit
% Edit the default stylesheet

    edit(css_file_name);
end