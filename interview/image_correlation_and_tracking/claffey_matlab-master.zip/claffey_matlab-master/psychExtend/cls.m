function cls
% Clear Screen variable without noisy feedback from PsychToolbox

    evalc('clear Screen');
    
end
