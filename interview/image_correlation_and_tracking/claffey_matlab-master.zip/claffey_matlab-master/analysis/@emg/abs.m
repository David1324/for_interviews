function [e] = abs(e)
% Rectify the data of an emg object

    e.data = abs(e.data);
    
end

