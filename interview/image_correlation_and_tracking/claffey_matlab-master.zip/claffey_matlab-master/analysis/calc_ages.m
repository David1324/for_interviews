function [data] = calc_ages(a)
% No description

% Created by Claffey@Claffey at 15-Mar-2009 16:52:11

    data = mean([a.baby1.age, a.baby2.age]);

end
