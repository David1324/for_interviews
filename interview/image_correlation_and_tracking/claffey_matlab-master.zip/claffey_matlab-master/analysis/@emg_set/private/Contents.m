% PRIVATE
%
% Files
%   channel_names_to_indices - Converts the string names of channels to scalar indices    
%   isolate_channels         - Returns an emg_set with only the specified channels
%   remove_channels          - Returns en emg_set after removing the specified channel names
