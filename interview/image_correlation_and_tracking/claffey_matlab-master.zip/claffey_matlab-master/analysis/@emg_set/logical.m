function [is_true] = logical(e)
% Returns true if the emg_set is not empty    
    is_true = ~isempty(e);
end