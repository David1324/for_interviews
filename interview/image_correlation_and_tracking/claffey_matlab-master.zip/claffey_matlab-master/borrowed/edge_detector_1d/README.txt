1D Edge Detector
----------------

Written and made available by

	Center for the Computer Integrated Systems for Microscopy and Manipulation (CISMM)

at

	UNC Chapel Hill

Complete information can be found here:

	http://www.cs.unc.edu/~nanowork/cismm/download/edgedetector/index.html

The original package can be downloaded here:

	http://cismm.cs.unc.edu/downloads/?dl_cat=10
