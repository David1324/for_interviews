function ExitFunc()

