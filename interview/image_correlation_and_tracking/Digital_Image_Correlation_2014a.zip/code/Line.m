function Y=Line(Beta,XData)
        Y=Beta(1)*XData+Beta(2);