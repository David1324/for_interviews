function [Output] = FactorReductionFunc(Input,Options)
    Output = Input/Options;


