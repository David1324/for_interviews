% Do nothing (just return input as output)
function [Output] = DummyFunc(Input,Options)
    Output=Input;


