function ExitMPFunc()
	delete(gcp('nocreate'));


