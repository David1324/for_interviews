function [ValidXCurrent,ValidYCurrent,CorrCoefCurrent] = CollectDataFunc(InputCorrelX,InputCorrelY,InputCorrCoef)
    ValidXCurrent=InputCorrelX;
    ValidYCurrent=InputCorrelY;
	CorrCoefCurrent=InputCorrCoef;


