function [Output] = AdditionFunc(Input,Options)
    Output=Input+Options;


